import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Register User
  app.post(api.auth.register.path, async (req, res) => {
    try {
      const input = api.auth.register.input.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByPhone(input.phoneNumber);
      if (existingUser) {
        // Just return existing user for simplicity in this mock
        return res.status(201).json(existingUser);
      }
      
      const user = await storage.createUser(input);
      res.status(201).json(user);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Mock OTP Verification
  app.post(api.auth.verifyOtp.path, async (req, res) => {
    try {
      const input = api.auth.verifyOtp.input.parse(req.body);
      const user = await storage.getUserByPhone(input.phoneNumber);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // accept any OTP for this mock demo
      res.status(200).json({ success: true, user });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Trigger Emergency
  app.post(api.emergencies.trigger.path, async (req, res) => {
    try {
      const input = api.emergencies.trigger.input.parse(req.body);
      const emergency = await storage.createEmergency(input);
      res.status(201).json(emergency);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // List Emergencies
  app.get(api.emergencies.list.path, async (req, res) => {
    try {
      const emergenciesList = await storage.getAllEmergencies();
      res.status(200).json(emergenciesList);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  return httpServer;
}
