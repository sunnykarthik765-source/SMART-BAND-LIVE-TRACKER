import { db } from "./db";
import {
  users,
  emergencies,
  emergencyContacts,
  type User,
  type InsertUser,
  type Emergency,
  type InsertEmergency,
  type EmergencyContact,
  type InsertEmergencyContact
} from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByPhone(phoneNumber: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createEmergency(emergency: InsertEmergency): Promise<Emergency>;
  getEmergencies(userId: number): Promise<Emergency[]>;
  getAllEmergencies(): Promise<Emergency[]>;

  createContact(contact: InsertEmergencyContact): Promise<EmergencyContact>;
  getContacts(userId: number): Promise<EmergencyContact[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByPhone(phoneNumber: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.phoneNumber, phoneNumber));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async createEmergency(insertEmergency: InsertEmergency): Promise<Emergency> {
    const [emergency] = await db.insert(emergencies).values(insertEmergency).returning();
    return emergency;
  }

  async getEmergencies(userId: number): Promise<Emergency[]> {
    return await db.select().from(emergencies).where(eq(emergencies.userId, userId));
  }

  async getAllEmergencies(): Promise<Emergency[]> {
    return await db.select().from(emergencies);
  }

  async createContact(insertContact: InsertEmergencyContact): Promise<EmergencyContact> {
    const [contact] = await db.insert(emergencyContacts).values(insertContact).returning();
    return contact;
  }

  async getContacts(userId: number): Promise<EmergencyContact[]> {
    return await db.select().from(emergencyContacts).where(eq(emergencyContacts.userId, userId));
  }
}

export const storage = new DatabaseStorage();
