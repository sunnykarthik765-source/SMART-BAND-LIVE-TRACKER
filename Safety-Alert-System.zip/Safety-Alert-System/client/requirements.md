## Packages
framer-motion | Page transitions and complex pulsing animations for the SOS button

## Notes
The application relies on localStorage for simple mocked auth state after OTP verification.
Geolocation API requires a secure context (HTTPS) or localhost to function properly.
Maps are rendered using an iframe with CSS inversion to achieve a dark mode aesthetic without requiring an API key.
