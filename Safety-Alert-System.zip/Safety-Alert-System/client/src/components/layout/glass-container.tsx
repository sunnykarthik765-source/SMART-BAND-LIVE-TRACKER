import { HTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/utils";

interface GlassContainerProps extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
}

export function GlassContainer({ children, className, ...props }: GlassContainerProps) {
  return (
    <div 
      className={cn("glass-panel rounded-2xl p-4 md:p-6", className)} 
      {...props}
    >
      {children}
    </div>
  );
}
