import { User } from "@shared/schema";

const USER_KEY = "safety_app_user";
const TOKEN_KEY = "safety_app_token";

export const authStore = {
  getUser: (): User | null => {
    try {
      const data = localStorage.getItem(USER_KEY);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  },
  
  getToken: (): string | null => {
    return localStorage.getItem(TOKEN_KEY);
  },

  setAuth: (user: User, token: string) => {
    localStorage.setItem(USER_KEY, JSON.stringify(user));
    localStorage.setItem(TOKEN_KEY, token);
  },

  clearAuth: () => {
    localStorage.removeItem(USER_KEY);
    localStorage.removeItem(TOKEN_KEY);
  },
  
  isAuthenticated: () => {
    return !!localStorage.getItem(TOKEN_KEY);
  }
};
