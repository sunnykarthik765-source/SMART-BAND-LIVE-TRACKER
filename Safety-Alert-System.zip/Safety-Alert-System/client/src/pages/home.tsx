import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { User, MapPin, AlertOctagon, LogOut, Loader2 } from "lucide-react";
import { authStore } from "@/lib/auth-store";
import { useGeolocation } from "@/hooks/use-geolocation";
import { useTriggerEmergency } from "@/hooks/use-emergencies";
import { useToast } from "@/hooks/use-toast";
import { GlassContainer } from "@/components/layout/glass-container";

export default function Home() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const user = authStore.getUser();
  const { coords, error, isLoading } = useGeolocation();
  const triggerMutation = useTriggerEmergency();
  
  const [isPressing, setIsPressing] = useState(false);

  useEffect(() => {
    if (!authStore.isAuthenticated()) {
      setLocation("/register");
    }
  }, [setLocation]);

  const handleLogout = () => {
    authStore.clearAuth();
    setLocation("/");
  };

  const handleEmergency = () => {
    if (!coords) {
      toast({ 
        title: "Location Unavailable", 
        description: "Cannot send precise coordinates. Triggering anyway.",
        variant: "destructive"
      });
    }

    const payload = {
      lat: coords?.lat || 0,
      lng: coords?.lng || 0,
      userId: user?.id || 1 // Fallback if mock auth didn't set ID correctly
    };

    triggerMutation.mutate(payload, {
      onSuccess: () => {
        // Requested behavior: JS Alert and open phone dialer
        alert(`EMERGENCY SIGNAL SENT!\nI am in danger! I need help!\nMy location: ${payload.lat}, ${payload.lng}`);
        window.location.href = 'tel:9112345678';
      },
      onError: (err) => {
        toast({ title: "Failed to send signal", description: err.message, variant: "destructive" });
      }
    });
  };

  if (!user) return null;

  return (
    <div className="h-screen w-full relative bg-zinc-950 overflow-hidden">
      
      {/* Background Map Layer */}
      <div className="absolute inset-0 z-0">
        {coords ? (
          <iframe 
            width="100%" 
            height="100%" 
            style={{ border: 0 }}
            loading="lazy"
            allowFullScreen
            src={`https://maps.google.com/maps?q=${coords.lat},${coords.lng}&t=m&z=16&ie=UTF8&iwloc=&output=embed`}
            className="dark-map-filter object-cover w-full h-full opacity-60"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-zinc-900 opacity-50">
            {isLoading ? <Loader2 className="w-8 h-8 text-primary animate-spin" /> : <MapPin className="w-8 h-8 text-zinc-600" />}
          </div>
        )}
        {/* Vignette overlay for dramatic dark mode look */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-transparent via-zinc-950/50 to-zinc-950 z-10 pointer-events-none" />
      </div>

      {/* Top Navigation / Info Panels */}
      <div className="absolute top-0 inset-x-0 p-4 md:p-6 z-20 flex justify-between items-start pointer-events-none">
        
        {/* Left: User Info */}
        <GlassContainer className="pointer-events-auto flex items-center gap-3 py-3 px-4 max-w-[200px] md:max-w-xs">
          <div className="w-10 h-10 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center shrink-0">
            <User className="w-5 h-5 text-zinc-300" />
          </div>
          <div className="flex flex-col overflow-hidden">
            <span className="text-xs text-zinc-500 font-medium uppercase tracking-wider">Identity</span>
            <span className="text-sm font-bold text-white truncate">{user.fullName}</span>
          </div>
        </GlassContainer>

        {/* Right: Location & Logout */}
        <div className="flex flex-col items-end gap-3 pointer-events-auto">
          <GlassContainer className="flex items-center gap-3 py-3 px-4">
            <div className="flex flex-col items-end">
              <span className="text-xs text-zinc-500 font-medium uppercase tracking-wider">Location</span>
              {isLoading ? (
                <span className="text-sm font-bold text-zinc-400">Acquiring...</span>
              ) : error ? (
                <span className="text-sm font-bold text-red-400">Offline</span>
              ) : (
                <span className="text-sm font-bold text-emerald-400 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  Live Sync
                </span>
              )}
            </div>
            <div className="w-10 h-10 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center shrink-0">
              <MapPin className="w-5 h-5 text-emerald-400" />
            </div>
          </GlassContainer>
          
          <button 
            onClick={handleLogout}
            className="p-3 rounded-full bg-zinc-900/50 border border-white/10 text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors backdrop-blur-md"
          >
            <LogOut className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Center: The Big Button */}
      <div className="absolute inset-0 z-30 flex items-center justify-center pointer-events-none">
        <div className="pointer-events-auto relative">
          
          {/* Animated decorative rings */}
          <div className="absolute inset-0 bg-primary/20 rounded-full blur-xl animate-sos-pulse pointer-events-none scale-150" />
          <div className="absolute inset-0 bg-primary/40 rounded-full blur-md animate-sos-pulse-inner pointer-events-none scale-110" />

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onMouseDown={() => setIsPressing(true)}
            onMouseUp={() => setIsPressing(false)}
            onMouseLeave={() => setIsPressing(false)}
            onClick={handleEmergency}
            disabled={triggerMutation.isPending}
            className={`
              relative w-48 h-48 md:w-64 md:h-64 rounded-full flex flex-col items-center justify-center 
              bg-gradient-to-b from-red-500 to-red-700 border-4 border-red-400/50
              shadow-[0_0_50px_rgba(225,29,72,0.6),inset_0_4px_20px_rgba(255,255,255,0.4),inset_0_-4px_20px_rgba(0,0,0,0.4)]
              transition-all duration-200
              ${isPressing ? 'brightness-90 scale-95' : 'brightness-100'}
              disabled:opacity-80 disabled:cursor-not-allowed
            `}
          >
            <AlertOctagon className="w-16 h-16 md:w-20 md:h-20 text-white mb-2 drop-shadow-lg" />
            <span className="font-display text-4xl md:text-5xl font-black text-white tracking-widest drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]">
              SOS
            </span>
          </motion.button>
          
          <div className="absolute -bottom-16 inset-x-0 text-center text-sm font-medium text-zinc-400 drop-shadow-md">
            Tap to alert emergency contacts <br/> and broadcast location
          </div>
        </div>
      </div>

    </div>
  );
}
