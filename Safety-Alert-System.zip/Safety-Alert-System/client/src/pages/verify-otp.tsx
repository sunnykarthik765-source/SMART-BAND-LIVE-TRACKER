import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { LockKeyhole } from "lucide-react";
import { useVerifyOtp } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { GlassContainer } from "@/components/layout/glass-container";

export default function VerifyOtp() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const verifyMutation = useVerifyOtp();
  
  const [otp, setOtp] = useState(["", "", "", ""]);
  const phoneNumber = sessionStorage.getItem("pending_phone") || "";

  useEffect(() => {
    if (!phoneNumber && location === "/verify-otp") {
      setLocation("/register");
    }
  }, [phoneNumber, location, setLocation]);

  const handleChange = (index: number, value: string) => {
    if (value.length > 1) return; // Prevent multiple chars
    
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    // Auto-focus next input
    if (value !== "" && index < 3) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace" && otp[index] === "" && index > 0) {
      const prevInput = document.getElementById(`otp-${index - 1}`);
      prevInput?.focus();
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const otpValue = otp.join("");
    
    if (otpValue.length !== 4) {
      toast({ title: "Error", description: "Please enter a 4-digit code", variant: "destructive" });
      return;
    }

    verifyMutation.mutate({ phoneNumber, otp: otpValue }, {
      onSuccess: () => {
        sessionStorage.removeItem("pending_phone");
        toast({ title: "Device Secured", description: "Authentication successful." });
        setLocation("/home");
      },
      onError: (err) => {
        toast({ title: "Verification failed", description: err.message, variant: "destructive" });
      }
    });
  };

  return (
    <div className="min-h-screen bg-zinc-950 flex flex-col items-center justify-center p-4 md:p-6 relative">
      <div className="absolute top-0 left-0 w-[400px] h-[400px] bg-red-600/5 rounded-full blur-[100px] pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        className="w-full max-w-md z-10"
      >
        <GlassContainer className="p-8">
          <div className="flex flex-col items-center text-center mb-8">
            <div className="w-16 h-16 bg-zinc-900 border border-zinc-800 rounded-2xl flex items-center justify-center mb-4 shadow-lg">
              <LockKeyhole className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-2xl font-bold text-white mb-2">Verify Device</h1>
            <p className="text-zinc-400 text-sm">
              We sent a security code to <br/>
              <span className="text-white font-medium">{phoneNumber}</span>
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="flex justify-center gap-3 md:gap-4">
              {otp.map((digit, i) => (
                <input
                  key={i}
                  id={`otp-${i}`}
                  type="text"
                  inputMode="numeric"
                  value={digit}
                  onChange={(e) => handleChange(i, e.target.value)}
                  onKeyDown={(e) => handleKeyDown(i, e)}
                  className="w-14 h-16 md:w-16 md:h-18 text-center text-2xl font-bold bg-zinc-900/50 border border-zinc-800 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                />
              ))}
            </div>

            <button
              type="submit"
              disabled={verifyMutation.isPending}
              className="w-full py-3.5 rounded-xl font-bold bg-white hover:bg-zinc-200 text-zinc-950 shadow-[0_0_20px_rgba(255,255,255,0.1)] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {verifyMutation.isPending ? "VERIFYING..." : "CONFIRM CODE"}
            </button>
            
            <p className="text-center text-sm text-zinc-500 mt-4">
              Didn't receive code? <button type="button" className="text-primary hover:underline font-medium">Resend</button>
            </p>
          </form>
        </GlassContainer>
      </motion.div>
    </div>
  );
}
