import { useEffect } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { ShieldAlert, ArrowRight } from "lucide-react";
import { authStore } from "@/lib/auth-store";

export default function Intro() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    // Force dark mode for the app
    document.documentElement.classList.add('dark');
    
    // Auto-redirect if already logged in
    if (authStore.isAuthenticated()) {
      setLocation("/home");
    }
  }, [setLocation]);

  return (
    <div className="min-h-screen bg-zinc-950 flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Background gradients */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-red-600/10 rounded-full blur-[120px] pointer-events-none" />
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="max-w-md w-full z-10 flex flex-col items-center text-center"
      >
        <motion.div 
          className="relative mb-12"
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        >
          <div className="absolute inset-0 bg-red-500/20 blur-2xl rounded-full" />
          <div className="w-32 h-32 bg-zinc-900 border border-zinc-800 rounded-full flex items-center justify-center relative z-10 shadow-2xl animate-sos-pulse-inner">
            <ShieldAlert className="w-16 h-16 text-primary" />
          </div>
        </motion.div>

        <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 leading-tight">
          Personal Safety, <br/>
          <span className="text-primary">Always Active.</span>
        </h1>
        
        <p className="text-zinc-400 mb-12 text-lg">
          Transform your device into an advanced emergency beacon. Immediate response when you need it most.
        </p>

        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setLocation("/register")}
          className="w-full py-4 rounded-xl font-bold text-lg bg-primary hover:bg-primary/90 text-white shadow-lg shadow-red-500/25 transition-colors flex items-center justify-center gap-2 group"
        >
          SECURE DEVICE
          <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </motion.button>
      </motion.div>
    </div>
  );
}
