import { useMutation } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { InsertUser, VerifyOtpRequest } from "@shared/schema";
import { authStore } from "@/lib/auth-store";

export function useRegister() {
  return useMutation({
    mutationFn: async (data: InsertUser) => {
      // Validate input using the shared schema
      const validated = api.auth.register.input.parse(data);
      
      const res = await fetch(api.auth.register.path, {
        method: api.auth.register.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.auth.register.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Registration failed");
      }
      
      // Usually we'd return 201, but we parse it based on API contract
      return api.auth.register.responses[201].parse(await res.json());
    },
  });
}

export function useVerifyOtp() {
  return useMutation({
    mutationFn: async (data: VerifyOtpRequest) => {
      const validated = api.auth.verifyOtp.input.parse(data);
      
      const res = await fetch(api.auth.verifyOtp.path, {
        method: api.auth.verifyOtp.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.auth.verifyOtp.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        if (res.status === 404) {
          throw new Error("User not found or OTP expired");
        }
        throw new Error("OTP Verification failed");
      }
      
      const responseData = api.auth.verifyOtp.responses[200].parse(await res.json());
      
      if (responseData.success) {
        // Since API doesn't specify returning a token in this snippet, we'll mock one
        // If it did, we'd use responseData.token
        authStore.setAuth(responseData.user, "mock-jwt-token-xyz");
      }
      
      return responseData;
    },
  });
}
