import { useMutation, useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { InsertEmergency } from "@shared/schema";
import { authStore } from "@/lib/auth-store";

export function useTriggerEmergency() {
  return useMutation({
    mutationFn: async (data: InsertEmergency) => {
      const validated = api.emergencies.trigger.input.parse(data);
      const token = authStore.getToken();
      
      const res = await fetch(api.emergencies.trigger.path, {
        method: api.emergencies.trigger.method,
        headers: { 
          "Content-Type": "application/json",
          ...(token ? { "Authorization": `Bearer ${token}` } : {})
        },
        body: JSON.stringify(validated),
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.emergencies.trigger.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to trigger emergency");
      }
      
      return api.emergencies.trigger.responses[201].parse(await res.json());
    },
  });
}

export function useEmergencies() {
  return useQuery({
    queryKey: [api.emergencies.list.path],
    queryFn: async () => {
      const token = authStore.getToken();
      const res = await fetch(api.emergencies.list.path, {
        headers: {
          ...(token ? { "Authorization": `Bearer ${token}` } : {})
        }
      });
      
      if (!res.ok) {
        throw new Error("Failed to fetch emergencies");
      }
      
      return api.emergencies.list.responses[200].parse(await res.json());
    }
  });
}
