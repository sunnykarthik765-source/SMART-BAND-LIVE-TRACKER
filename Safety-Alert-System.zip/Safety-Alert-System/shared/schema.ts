import { pgTable, text, serial, timestamp, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  phoneNumber: text("phone_number").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const emergencyContacts = pgTable("emergency_contacts", {
  id: serial("id").primaryKey(),
  userId: serial("user_id").references(() => users.id),
  name: text("name").notNull(),
  phoneNumber: text("phone_number").notNull(),
});

export const emergencies = pgTable("emergencies", {
  id: serial("id").primaryKey(),
  userId: serial("user_id").references(() => users.id),
  lat: doublePrecision("lat").notNull(),
  lng: doublePrecision("lng").notNull(),
  status: text("status").notNull().default("active"),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertEmergencyContactSchema = createInsertSchema(emergencyContacts).omit({ id: true });
export const insertEmergencySchema = createInsertSchema(emergencies).omit({ id: true, timestamp: true, status: true });

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type EmergencyContact = typeof emergencyContacts.$inferSelect;
export type InsertEmergencyContact = z.infer<typeof insertEmergencyContactSchema>;

export type Emergency = typeof emergencies.$inferSelect;
export type InsertEmergency = z.infer<typeof insertEmergencySchema>;

// API Contract Types
export type VerifyOtpRequest = { phoneNumber: string; otp: string };
export type LoginResponse = { user: User; token: string };

export type CreateEmergencyRequest = InsertEmergency;
export type EmergencyResponse = Emergency;
