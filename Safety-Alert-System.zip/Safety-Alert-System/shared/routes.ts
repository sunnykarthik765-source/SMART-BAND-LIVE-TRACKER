import { z } from 'zod';
import { insertUserSchema, insertEmergencySchema, users, emergencies } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  auth: {
    register: {
      method: 'POST' as const,
      path: '/api/auth/register' as const,
      input: insertUserSchema,
      responses: {
        201: z.custom<typeof users.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    verifyOtp: {
      method: 'POST' as const,
      path: '/api/auth/verify-otp' as const,
      input: z.object({
        phoneNumber: z.string(),
        otp: z.string(),
      }),
      responses: {
        200: z.object({
          success: z.boolean(),
          user: z.custom<typeof users.$inferSelect>(),
        }),
        400: errorSchemas.validation,
        404: errorSchemas.notFound,
      },
    },
  },
  emergencies: {
    trigger: {
      method: 'POST' as const,
      path: '/api/emergencies' as const,
      input: insertEmergencySchema,
      responses: {
        201: z.custom<typeof emergencies.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
    list: {
      method: 'GET' as const,
      path: '/api/emergencies' as const,
      responses: {
        200: z.array(z.custom<typeof emergencies.$inferSelect>()),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
